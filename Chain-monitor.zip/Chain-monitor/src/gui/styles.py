# styles.py

# Dark theme stylesheet with all component-specific styles

DARK_STYLE = """
/* Base styles for all widgets */
QMainWindow, QDialog, QWidget {
    background-color: #1e1e1e;
    color: #e0e0e0;
}

QLabel {
    color: #e0e0e0;
    font-size: 16px;
    padding: 5px;
}

QPushButton {
    background-color: #0d47a1;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    font-size: 16px;
    min-height: 36px;
    min-width: 100px;
}

QPushButton:hover {
    background-color: #1565c0;
}

QPushButton:pressed {
    background-color: #0a3d91;
}

QPushButton:disabled {
    background-color: #465975;
    color: #a0a0a0;
}

QFrame {
    background-color: #2d2d2d;
    border-radius: 8px;
    padding: 12px;
}

/* Table styles */
QTableWidget {
    background-color: #252525;
    alternate-background-color: #2a2a2a;
    border: 1px solid #444444;
    gridline-color: #444444;
    color: #e0e0e0;
    font-size: 15px;
    selection-background-color: #0d47a1;
    selection-color: #ffffff;
}

QTableWidget::item {
    border: none;
    padding: 8px;
    min-height: 30px;
}

QTableWidget::item:selected {
    background-color: #0d47a1;
    color: white;
}

/* Header styles */
QHeaderView::section {
    background-color: #333333;
    color: #e0e0e0;
    padding: 10px;
    border: 1px solid #444444;
    font-size: 15px;
    font-weight: bold;
    min-height: 30px;
}

QHeaderView {
    background-color: #333333;
}

/* Measurements tab specific styles */
QTableWidget#measurementsTable::item {
    padding: 8px;
}

/* Warnings tab specific styles */
QTableWidget#warningsTable::item {
    padding: 8px;
    color: #ff9999;
}

/* Scroll bar styles */
QScrollBar:vertical {
    background-color: #2d2d2d;
    width: 14px;
    margin: 18px 0 18px 0;
}

QScrollBar::handle:vertical {
    background-color: #555555;
    min-height: 24px;
    border-radius: 5px;
}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    border: none;
    background: none;
}

/* Video frame styles */
QLabel#videoFrame {
    background-color: #252525;
    border: 1px solid #444444;
    border-radius: 4px;
}

/* Title styles */
QLabel#appTitle {
    font-size: 22px;
    font-weight: bold;
}

QLabel#statusLabel {
    font-size: 16px;
}

/* Group box styles */
QGroupBox {
    border: 1px solid #444444;
    border-radius: 6px;
    margin-top: 1.8ex;
    background-color: #2d2d2d;
    color: #e0e0e0;
    font-size: 15px;
}

QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top center;
    padding: 0 6px;
    color: #e0e0e0;
    font-size: 16px;
}

/* Tab widget styles */
QTabWidget::pane {
    border: 1px solid #444444;
    border-radius: 6px;
    background-color: #2d2d2d;
}

QTabBar::tab {
    background-color: #1e1e1e;
    color: #e0e0e0;
    border: 1px solid #444444;
    border-bottom: none;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
    padding: 8px 14px;
    margin-right: 3px;
    font-size: 15px;
}

QTabBar::tab:selected {
    background-color: #2d2d2d;
    border-bottom: none;
    font-weight: bold;
}

/* Other styles from the original stylesheet */
QScrollArea, QScrollBar {
    background-color: #2d2d2d;
    border-radius: 5px;
}

QProgressBar {
    border: 1px solid #444444;
    border-radius: 5px;
    text-align: center;
    background-color: #252525;
    color: #e0e0e0;
    font-size: 14px;
    min-height: 20px;
}

QProgressBar::chunk {
    background-color: #0d47a1;
    width: 12px;
    margin: 0.6px;
}

QSplitter::handle {
    background-color: #444444;
    width: 2px;
}

QStatusBar {
    background-color: #1e1e1e;
    color: #e0e0e0;
    font-size: 14px;
    padding: 4px;
}

/* Estilo para menu e menu items */
QMenuBar {
    background-color: #1e1e1e;
    color: #e0e0e0;
    font-size: 15px;
}

QMenuBar::item {
    background-color: transparent;
    padding: 6px 12px;
}

QMenuBar::item:selected {
    background-color: #2d2d2d;
}

QMenu {
    background-color: #2d2d2d;
    color: #e0e0e0;
    border: 1px solid #444444;
    font-size: 15px;
}

QMenu::item {
    padding: 6px 25px 6px 20px;
}

QMenu::item:selected {
    background-color: #0d47a1;
}

/* Spinner e combobox */
QSpinBox, QDoubleSpinBox, QComboBox {
    background-color: #252525;
    border: 1px solid #444444;
    border-radius: 5px;
    color: #e0e0e0;
    padding: 4px 6px;
    min-height: 28px;
    font-size: 15px;
}

QComboBox::drop-down {
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 20px;
    border-left-width: 1px;
    border-left-color: #444444;
    border-left-style: solid;
}

QProgressBar {
    background-color: #252525;
    border: 1px solid #444444;
    border-radius: 5px;
    text-align: center;
    color: white;
    font-size: 14px;
    height: 25px;
}

QProgressBar::chunk {
    background-color: #0d47a1;
    width: 5px;
    margin: 0.5px;
    border-radius: 3px;
}

QDoubleSpinBox {
    background-color: #252525;
    border: 1px solid #444444;
    border-radius: 4px;
    padding: 4px;
    color: #e0e0e0;
    font-size: 15px;
    min-height: 26px;
}

QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {
    width: 20px;
    background-color: #333333;
    border: 1px solid #444444;
}

QDoubleSpinBox::up-button:hover, QDoubleSpinBox::down-button:hover {
    background-color: #0d47a1;
}

QGroupBox {
    border: 1px solid #444444;
    border-radius: 6px;
    margin-top: 1.5ex;
    padding: 10px;
    background-color: #2d2d2d;
    color: #e0e0e0;
    font-size: 15px;
}

QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top center;
    padding: 0 5px;
    color: #e0e0e0;
    font-size: 16px;
}
"""

# Additional specific styles that can be applied programmatically
TABLE_HEADER_HEIGHT = 100  # Constant for table header height
MEASUREMENT_COLUMN_WIDTHS = [120, 180, 180]  # Standard widths for measurement columns
WARNING_COLUMN_WIDTHS = [120, 180, 280]  # Standard widths for warning columns