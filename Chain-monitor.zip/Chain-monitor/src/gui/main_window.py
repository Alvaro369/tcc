import sys
import os
from pathlib import Path

# Adicionar diretório raiz ao path do Python
current_dir = Path(__file__).parent
parent_dir = current_dir.parent.parent
sys.path.append(str(parent_dir))

from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                            QPushButton, QLabel, QProgressBar, QFileDialog,
                            QSplitter, QFrame, QScrollArea, QGridLayout,
                            QGroupBox, QTabWidget, QTableWidget, QTableWidgetItem,
                            QHeaderView, QDoubleSpinBox, QStatusBar)
from PyQt5.QtCore import Qt, QSize, pyqtSignal
from PyQt5.QtGui import QPixmap, QFont, QIcon, QColor, QImage
import numpy as np
import cv2

# Agora você pode importar de src
from src.gui.styles import DARK_STYLE

# Tentar importar os componentes do gráfico
try:
    from PyQt5.QtChart import QChart, QChartView, QLineSeries, QValueAxis
    from PyQt5.QtGui import QPainter, QPen
    HAS_CHART_SUPPORT = True
except ImportError:
    HAS_CHART_SUPPORT = False
    print("PyQtChart não disponível - funcionalidades de gráfico serão desabilitadas.")

class MainWindow(QMainWindow):
    # Declarar os sinais da classe
    wear_limit_changed = pyqtSignal(float)
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Sistema de Monitoramento de Correntes")
        self.setMinimumSize(1200, 800)
        
        # Inicializar valores padrão
        self.wear_limit = 128.5  # valor padrão para o limite de desgaste
        
        # Verificar suporte a gráficos
        self.has_chart_support = False
        try:
            from PyQt5.QtChart import QChart, QChartView, QLineSeries, QValueAxis
            self.has_chart_support = True
            print("Suporte a gráficos PyQtChart detectado com sucesso")
        except ImportError:
            print("AVISO: PyQtChart não encontrado. A aba de gráfico será desabilitada.")
            print("Para habilitar gráficos, instale com: pip install PyQtChart")
        
        # Inicializar atributos relacionados ao gráfico para evitar erros
        self.measurement_series = None
        self.threshold_series = None
        self.measurement_chart = None
        
        # Set up the central widget and layout
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        
        # Main layout
        self.main_layout = QVBoxLayout(self.central_widget)
        
        # Create header
        self.create_header()
        
        # Create main content area with splitter
        self.content_splitter = QSplitter(Qt.Horizontal)
        self.main_layout.addWidget(self.content_splitter, 1)
        
        # Create video display area
        self.create_video_area()
        
        # Create stats panel
        self.create_stats_panel()
        
        # Create bottom control bar
        self.create_control_bar()
        
        # Set initial splitter sizes
        self.content_splitter.setSizes([700, 500])
        
        # Create status bar
        self.status_bar = QStatusBar(self)  # Renomear para status_bar
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Sistema pronto")
    
    def create_header(self):
        header_widget = QWidget()
        header_layout = QHBoxLayout(header_widget)
        header_layout.setContentsMargins(10, 5, 10, 5)
        
        # Adicionar logo Savision
        logo_label = QLabel()
        
        # Construir caminho para o logo
        project_root = Path(__file__).parent.parent.parent
        logo_path = project_root / "resources" / "images" / "savision.png"
        
        # Verificar se o arquivo existe
        if os.path.exists(logo_path):
            logo_pixmap = QPixmap(str(logo_path))
            # Redimensionar para um tamanho adequado ao banner
            logo_pixmap = logo_pixmap.scaled(180, 50, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            logo_label.setPixmap(logo_pixmap)
        else:
            # Fallback para texto caso a imagem não seja encontrada
            logo_label.setText("SAVISION")
            logo_label.setFont(QFont("Arial", 22, QFont.Bold))
        
        header_layout.addWidget(logo_label)
        
        # Título do aplicativo
        app_title = QLabel("SAVISION CHAIN MONITOR")
        app_title.setObjectName("appTitle")  # Permite estilização específica no CSS
        app_title.setFont(QFont("Arial", 22, QFont.Bold))
        header_layout.addWidget(app_title)
        
        # Add some space
        header_layout.addStretch()
        
        # Status indicator
        self.status_indicator = QLabel("Status: Parado")
        self.status_indicator.setObjectName("statusLabel")  # Permite estilização específica no CSS
        self.status_indicator.setFont(QFont("Arial", 16))
        header_layout.addWidget(self.status_indicator)
        
        self.main_layout.addWidget(header_widget)
        
        # Add separator line
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        self.main_layout.addWidget(line)
    
    def create_video_area(self):
        # Video display container
        video_container = QWidget()
        video_layout = QVBoxLayout(video_container)
        video_layout.setContentsMargins(10, 10, 10, 10)
        
        # Video display title
        video_title = QLabel("Visualização de Vídeo")
        video_title.setFont(QFont("Arial", 12, QFont.Bold))
        video_layout.addWidget(video_title)
        
        # Frame display
        self.video_frame = QLabel()
        self.video_frame.setAlignment(Qt.AlignCenter)
        self.video_frame.setMinimumSize(640, 480)
        self.video_frame.setStyleSheet("background-color: #252525; border: 1px solid #444444; border-radius: 4px;")
        self.video_frame.setText("Vídeo será exibido aqui")
        video_layout.addWidget(self.video_frame, 1)
        
        # Add to splitter
        self.content_splitter.addWidget(video_container)
    
    def create_stats_panel(self):
        stats_panel = QWidget()
        stats_layout = QVBoxLayout(stats_panel)
        
        # Create tab widget for different stats views
        self.tab_widget = QTabWidget()
        stats_layout.addWidget(self.tab_widget)
        
        # Create tabs
        self.create_summary_tab()
        self.create_measurements_tab()
        self.create_warnings_tab()
        
        # Create chart tab if chart support is available
        if self.has_chart_support:
            self.create_chart_tab()  # Certifique-se de que isso é chamado apenas uma vez
        
        self.content_splitter.addWidget(stats_panel)
    
    def create_summary_tab(self):
        summary_tab = QWidget()
        layout = QGridLayout(summary_tab)
        
        # Create stat boxes
        self.elo_count_label = self.create_stat_box("Elos Detectados", "0", layout, 0, 0)
        self.rolete_count_label = self.create_stat_box("Roletes Detectados", "0", layout, 0, 1)
        self.parafuso1_count_label = self.create_stat_box("Parafusos Tipo 1", "0", layout, 1, 0)
        self.parafuso2_count_label = self.create_stat_box("Parafusos Tipo 2", "0", layout, 1, 1)
        self.arrastador_count_label = self.create_stat_box("Arrastadores", "0", layout, 2, 0)
        self.current_measurement_label = self.create_stat_box("Medida Atual", "0.00 mm", layout, 2, 1)
        self.corrente_length_label = self.create_stat_box("Comprimento Total", "0.00 m", layout, 3, 0)
        self.worn_links_label = self.create_stat_box("Elos para Troca", "0", layout, 3, 1, warning=True)
        
        # Add some space
        layout.setRowStretch(4, 1)
        
        self.tab_widget.addTab(summary_tab, "Resumo")
    
    def create_stat_box(self, title, value, layout, row, col, warning=False):
        group_box = QGroupBox(title)
        box_layout = QVBoxLayout(group_box)
        
        value_label = QLabel(value)
        value_label.setFont(QFont("Arial", 20, QFont.Bold))  # Aumentado de 18
        value_label.setAlignment(Qt.AlignCenter)
        if warning:
            value_label.setStyleSheet("color: #e74c3c;")
        box_layout.addWidget(value_label)
        
        layout.addWidget(group_box, row, col)
        return value_label
    
    def create_measurements_tab(self):
        measurements_tab = QWidget()
        layout = QVBoxLayout(measurements_tab)
        
        # Create table for measurements
        self.measurements_table = QTableWidget(0, 3)
        self.measurements_table.setObjectName("measurementsTable")  # Set ID for CSS
        self.measurements_table.setHorizontalHeaderLabels(["Elo #", "Medida (mm)", "Status"])
        
        # Configure header and columns
        header = self.measurements_table.horizontalHeader()
        header.setStretchLastSection(False)
        
        # Configure resizing mode
        for i in range(3):
            header.setSectionResizeMode(i, QHeaderView.Interactive)
        
        # Set column widths using constants from styles
        from src.gui.styles import MEASUREMENT_COLUMN_WIDTHS
        for i, width in enumerate(MEASUREMENT_COLUMN_WIDTHS):
            self.measurements_table.setColumnWidth(i, width)
        
        # Visual adjustments
        self.measurements_table.setAlternatingRowColors(True)
        self.measurements_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.measurements_table.verticalHeader().setVisible(False)
        
        # Ensure header is visible with appropriate height
        header.setVisible(True)
        header.setDefaultSectionSize(120)
        
        from src.gui.styles import TABLE_HEADER_HEIGHT
        header.setMinimumHeight(TABLE_HEADER_HEIGHT)
        
        layout.addWidget(self.measurements_table)
        
        self.tab_widget.addTab(measurements_tab, "Medições")
    
    def create_warnings_tab(self):
        warnings_tab = QWidget()
        layout = QVBoxLayout(warnings_tab)
        
        # Title and explanation
        warning_title = QLabel("Alertas de Desgaste")
        warning_title.setFont(QFont("Arial", 10, QFont.Bold))
        layout.addWidget(warning_title)
        
        # Armazenar referência ao objeto de texto para atualizá-lo quando o limite mudar
        self.warning_info = QLabel(f"Elos com medidas acima de {self.wear_limit:.1f}mm são considerados desgastados e devem ser substituídos.")
        self.warning_info.setWordWrap(True)
        layout.addWidget(self.warning_info)
        
        # Warning list
        self.warnings_table = QTableWidget(0, 3)
        self.warnings_table.setObjectName("warningsTable")  # Set ID for CSS
        self.warnings_table.setHorizontalHeaderLabels(["Elo #", "Medida (mm)", "Localização"])
        
        # Configure header and columns
        header = self.warnings_table.horizontalHeader()
        header.setStretchLastSection(True)
        
        # Configure resizing mode
        header.setSectionResizeMode(0, QHeaderView.Interactive)
        header.setSectionResizeMode(1, QHeaderView.Interactive)
        header.setSectionResizeMode(2, QHeaderView.Stretch)
        
        # Set column widths using constants from styles
        from src.gui.styles import WARNING_COLUMN_WIDTHS
        for i, width in enumerate(WARNING_COLUMN_WIDTHS[:2]):  # Only first two columns
            self.warnings_table.setColumnWidth(i, width)
        
        # Visual adjustments
        self.warnings_table.setAlternatingRowColors(True)
        self.warnings_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.warnings_table.verticalHeader().setVisible(False)
        
        # Ensure header is visible with appropriate height
        header.setVisible(True)
        header.setDefaultSectionSize(120)
        
        from src.gui.styles import TABLE_HEADER_HEIGHT
        header.setMinimumHeight(TABLE_HEADER_HEIGHT)
        
        layout.addWidget(self.warnings_table)
        
        self.tab_widget.addTab(warnings_tab, "Alertas")
    
    def create_chart_tab(self):
        """Cria a aba de gráfico para visualização de medições"""
        # Importar módulos necessários aqui para garantir que existam
        from PyQt5.QtChart import QChart, QChartView, QLineSeries, QValueAxis
        from PyQt5.QtGui import QPainter, QPen
        from PyQt5.QtCore import Qt
        
        chart_tab = QWidget()
        layout = QVBoxLayout(chart_tab)
        
        # Criar séries para medições
        self.measurement_series = QLineSeries()
        self.measurement_series.setName("Medidas dos Elos (mm)")
        
        # Criar série para linha de limite
        self.threshold_series = QLineSeries()
        self.threshold_series.setName("Limite de Desgaste (128.5mm)")
        
        # Configurar estilo da linha de limite
        pen = QPen(Qt.red)
        pen.setStyle(Qt.DashLine)
        pen.setWidth(2)
        self.threshold_series.setPen(pen)
        
        # Linha de limite inicial
        self.threshold_series.append(0, 128.5)
        self.threshold_series.append(10, 128.5)
        
        # Criar gráfico
        self.measurement_chart = QChart()
        self.measurement_chart.setTitle("Evolução das Medidas dos Elos")
        self.measurement_chart.addSeries(self.measurement_series)
        self.measurement_chart.addSeries(self.threshold_series)
        
        # Criar eixo X
        x_axis = QValueAxis()
        x_axis.setTitleText("Número do Elo")
        x_axis.setRange(0, 10)
        x_axis.setTickCount(11)
        x_axis.setLabelFormat("%d")
        
        # Criar eixo Y
        y_axis = QValueAxis()
        y_axis.setTitleText("Medida (mm)")
        y_axis.setRange(100, 130)
        y_axis.setTickCount(7)
        y_axis.setLabelFormat("%.1f")
        
        # Definir eixos para o gráfico
        self.measurement_chart.setAxisX(x_axis, self.measurement_series)
        self.measurement_chart.setAxisY(y_axis, self.measurement_series)
        self.measurement_chart.setAxisX(x_axis, self.threshold_series)
        self.measurement_chart.setAxisY(y_axis, self.threshold_series)
        
        # Legenda
        self.measurement_chart.legend().setVisible(True)
        self.measurement_chart.legend().setAlignment(Qt.AlignBottom)
        
        # Visualização do gráfico
        chart_view = QChartView(self.measurement_chart)
        chart_view.setRenderHint(QPainter.Antialiasing)
        chart_view.setMinimumHeight(300)
        
        layout.addWidget(chart_view)
        
        # Texto explicativo
        explanation = QLabel("Este gráfico mostra a medida de cada elo detectado. "
                             "A linha tracejada vermelha indica o limite de desgaste (128.5mm).")
        explanation.setWordWrap(True)
        layout.addWidget(explanation)
        
        self.tab_widget.addTab(chart_tab, "Gráfico")
        print("Aba de gráfico criada com sucesso")
        return chart_tab
    
    def create_fallback_chart_tab(self):
        """Cria uma aba alternativa quando o suporte a gráficos não está disponível"""
        fallback_tab = QWidget()
        layout = QVBoxLayout(fallback_tab)
        
        info_label = QLabel(
            "O suporte a gráficos não está disponível.\n\n"
            "Para habilitar a visualização de gráficos, instale o PyQtChart:\n"
            "pip install PyQtChart\n\n"
            "Depois de instalar, reinicie a aplicação."
        )
        info_label.setAlignment(Qt.AlignCenter)
        info_label.setStyleSheet("font-size: 16px; padding: 20px;")
        
        layout.addWidget(info_label)
        layout.addStretch()
        
        self.tab_widget.addTab(fallback_tab, "Gráfico")
        print("Aba de fallback para gráfico criada")
    
    def create_control_bar(self):
        control_bar = QWidget()
        main_control_layout = QVBoxLayout(control_bar)  # Layout principal
        main_control_layout.setContentsMargins(10, 10, 10, 10)
        
        # Layout para controles superiores (botões e configurações)
        upper_controls = QHBoxLayout()
        
        # Configurações de limite (novo)
        limit_group = QGroupBox("Limite de Desgaste")
        limit_layout = QHBoxLayout(limit_group)
        
        limit_label = QLabel("Valor (mm):")
        limit_layout.addWidget(limit_label)
        
        # Campo para definir o limite de desgaste
        self.limit_input = QDoubleSpinBox()
        self.limit_input.setRange(120.0, 140.0)  # Intervalo razoável para medidas
        self.limit_input.setValue(self.wear_limit)  # Usar o valor padrão definido no __init__
        self.limit_input.setSingleStep(0.1)      # Incremento de 0.1mm
        self.limit_input.setDecimals(1)          # Uma casa decimal
        self.limit_input.setSuffix(" mm")        # Indicar unidade
        limit_layout.addWidget(self.limit_input)
        
        # Botão para salvar o limite - adicionar aqui
        self.save_limit_button = QPushButton("Aplicar Limite")
        self.save_limit_button.setIcon(QIcon.fromTheme("document-save"))
        limit_layout.addWidget(self.save_limit_button)
        
        upper_controls.addWidget(limit_group)
        
        # Adicionar separação
        upper_controls.addStretch()
        
        # Video source selection (existente)
        self.source_button = QPushButton("Selecionar Vídeo")
        self.source_button.setIcon(QIcon.fromTheme("document-open"))
        upper_controls.addWidget(self.source_button)
        
        # Add clean view toggle (existente)
        self.clean_view_toggle = QPushButton("Limpar Vídeo")
        self.clean_view_toggle.setCheckable(True)
        self.clean_view_toggle.setChecked(True)
        upper_controls.addWidget(self.clean_view_toggle)
        
        # Adicionar layout superior ao layout principal
        main_control_layout.addLayout(upper_controls)
        
        # Layout para botões de controle
        buttons_layout = QHBoxLayout()
        buttons_layout.setSpacing(10)
        
        # Control buttons (existentes)
        self.start_button = QPushButton("Iniciar")
        self.start_button.setIcon(QIcon.fromTheme("media-playback-start"))
        buttons_layout.addWidget(self.start_button)
        
        self.stop_button = QPushButton("Parar")
        self.stop_button.setIcon(QIcon.fromTheme("media-playback-stop"))
        buttons_layout.addWidget(self.stop_button)
        
        self.reset_button = QPushButton("Reiniciar")
        self.reset_button.setIcon(QIcon.fromTheme("view-refresh"))
        buttons_layout.addWidget(self.reset_button)
        
        self.save_button = QPushButton("Salvar Relatório")
        self.save_button.setIcon(QIcon.fromTheme("document-save"))
        buttons_layout.addWidget(self.save_button)
        
        # Adicionar layout de botões ao layout principal
        main_control_layout.addLayout(buttons_layout)
        
        # Adicionar barra de progresso
        progress_layout = QHBoxLayout()
        progress_label = QLabel("Progresso do Vídeo:")
        progress_layout.addWidget(progress_label)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("%p%")
        progress_layout.addWidget(self.progress_bar, 1)
        
        main_control_layout.addLayout(progress_layout)
        
        self.main_layout.addWidget(control_bar)
        
        # Conectar o botão de limite - agora está correto porque o botão já foi criado
        self.save_limit_button.clicked.connect(self.update_wear_limit)
    
    # Adicionar um método para atualizar o limite de desgaste
    def update_wear_limit(self):
        """Update the wear limit threshold based on user input"""
        new_limit = self.limit_input.value()
        self.wear_limit = new_limit  # Atualizar o valor na classe
        
        # Atualizar a linha de limite no gráfico se disponível
        if hasattr(self, 'threshold_series') and self.threshold_series is not None:
            try:
                # Atualizar a linha de limite com o novo valor
                point_count = self.threshold_series.count()
                if point_count > 0:
                    x_values = [self.threshold_series.at(i).x() for i in range(point_count)]
                    self.threshold_series.clear()
                    for x in x_values:
                        self.threshold_series.append(x, new_limit)
                else:
                    # Se não houver pontos, adicionar linha padrão
                    self.threshold_series.append(0, new_limit)
                    self.threshold_series.append(10, new_limit)
            except Exception as e:
                print(f"Erro ao atualizar linha de limite: {str(e)}")
        
        # Atualizar o texto explicativo na aba de alertas
        if hasattr(self, 'warning_info'):
            self.warning_info.setText(f"Elos com medidas acima de {new_limit:.1f}mm são considerados "
                                     f"desgastados e devem ser substituídos.")
        
        # Mostrar mensagem na barra de status
        self.status_bar.showMessage(f"Limite de desgaste atualizado para {new_limit:.1f}mm", 3000)
        
        # Emitir o sinal para atualizar o VideoProcessor
        self.wear_limit_changed.emit(new_limit)
    
    def update_frame(self, frame):
        """Update video frame display"""
        try:
            # Verificar se o frame é um array numpy (formato OpenCV)
            if isinstance(frame, np.ndarray):
                # Converter frame do OpenCV (BGR) para RGB
                rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                
                # Criar QImage a partir do array numpy
                height, width, channels = rgb_frame.shape
                bytes_per_line = channels * width
                q_img = QImage(rgb_frame.data, width, height, 
                              bytes_per_line, QImage.Format_RGB888)
                
                # Converter QImage para QPixmap
                pixmap = QPixmap.fromImage(q_img)
            else:
                # Se já for um QPixmap, usar diretamente
                pixmap = frame
                
            # Redimensionar e mostrar o frame
            self.video_frame.setPixmap(pixmap.scaled(
                self.video_frame.size(),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            ))
        except Exception as e:
            print(f"Erro ao atualizar frame: {str(e)}")
    
    def update_stats(self, stats):
        """Update all statistics displays with new values"""
        # Update summary tab
        self.elo_count_label.setText(str(stats['elo_count']))
        self.rolete_count_label.setText(str(stats['rolete_count']))
        self.parafuso1_count_label.setText(str(stats['parafuso1_count']))
        self.parafuso2_count_label.setText(str(stats['parafuso2_count']))
        self.arrastador_count_label.setText(str(stats['arrastador_count']))
        self.current_measurement_label.setText(f"{stats['current_measurement']:.2f} mm")
        self.corrente_length_label.setText(f"{stats['corrente_length']:.2f} m")
        self.worn_links_label.setText(str(stats['worn_links']))
        
        # Update status
        if stats['elo_count'] > 0:
            self.status_indicator.setText("Status: Monitorando")
            self.status_indicator.setStyleSheet("color: #2ecc71;")
        
        # Update measurements table
        self.update_measurements_table(stats)
        
        # Update warnings table
        self.update_warnings_table(stats)
        
        # Atualizar tabelas de medição e alertas
        # ... código existente ...
        
        # Atualizar gráfico se estiver disponível
        if self.has_chart_support and self.measurement_series is not None and self.measurement_chart is not None:
            try:
                current_elo = stats['elo_count']
                current_measurement = stats['current_measurement']
                
                # Adicionar ponto ao gráfico se for uma nova medição válida
                if current_measurement > 0 and current_elo > 0:
                    # Verificar se já existe este ponto no gráfico
                    exists = False
                    for i in range(self.measurement_series.count()):
                        if int(self.measurement_series.at(i).x()) == current_elo:
                            exists = True
                            break
                    
                    if not exists:
                        print(f"Adicionando ponto ao gráfico: ({current_elo}, {current_measurement})")
                        self.measurement_series.append(current_elo, current_measurement)
                        
                        # Atualizar linha de limite
                        if self.threshold_series is not None:
                            self.threshold_series.clear()
                            self.threshold_series.append(0, self.wear_limit)
                            self.threshold_series.append(current_elo + 5, self.wear_limit)
                        
                        # Ajustar eixos
                        x_axis = self.measurement_chart.axisX()
                        if x_axis:
                            x_axis.setRange(0, max(10, current_elo + 5))
                        
                        y_axis = self.measurement_chart.axisY()
                        if y_axis:
                            # Definir intervalo apropriado para o eixo Y
                            all_y_values = [self.measurement_series.at(i).y() 
                                           for i in range(self.measurement_series.count())]
                            if all_y_values:
                                min_y = max(100, min(all_y_values) - 10)
                                max_y = max(130, max(all_y_values) + 10)
                                y_axis.setRange(min_y, max_y)
            except Exception as e:
                print(f"Erro ao atualizar gráfico: {str(e)}")
    
    def update_measurements_table(self, stats):
        """Update the measurements table with new data"""
        # Clear the table
        self.measurements_table.setRowCount(0)
        
        # Add new measurements
        for i, measurement in enumerate(stats['medidas_elo']):
            row_position = self.measurements_table.rowCount()
            self.measurements_table.insertRow(row_position)
            
            # Elo number
            self.measurements_table.setItem(row_position, 0, QTableWidgetItem(str(i + 1)))
            
            # Measurement value
            self.measurements_table.setItem(row_position, 1, QTableWidgetItem(f"{measurement:.2f} mm"))
            
            # Status
            status = "OK" if measurement < self.wear_limit else "Desgastado"
            status_item = QTableWidgetItem(status)
            if status == "Desgastado":
                status_item.setForeground(QColor(231, 76, 60))  # Red color for worn links
            else:
                status_item.setForeground(QColor(46, 204, 113))  # Green color for OK status
            self.measurements_table.setItem(row_position, 2, status_item)
    
    def update_warnings_table(self, stats):
        """Update the warnings table with new data"""
        # Clear the table
        self.warnings_table.setRowCount(0)
        
        # Add new warnings
        for i, measurement in enumerate(stats['medidas_elo']):
            if measurement >= self.wear_limit:
                row_position = self.warnings_table.rowCount()
                self.warnings_table.insertRow(row_position)
                
                # Elo number
                self.warnings_table.setItem(row_position, 0, QTableWidgetItem(str(i + 1)))
                
                # Measurement value
                self.warnings_table.setItem(row_position, 1, QTableWidgetItem(f"{measurement:.2f} mm"))
                
                # Location (example: "a 0.5m do início")
                location = stats['localizacao_elo'][i]
                self.warnings_table.setItem(row_position, 2, QTableWidgetItem(location))
    
    def add_warning_message(self, message):
        """Display a warning message in the warnings tab"""
        self.tab_widget.setCurrentIndex(2)  # Switch to warnings tab
        self.status_bar.showMessage(message, 5000)  # Show in status bar for 5 seconds
    
    def update_progress(self, percentage, current_frame=None, total_frames=None):
        """Update progress bar with current video processing progress"""
        self.progress_bar.setValue(int(percentage))
        
        # Se tivermos informações sobre os frames, atualizar o texto da barra
        if current_frame is not None and total_frames is not None:
            self.progress_bar.setMaximum(total_frames)
            self.progress_bar.setValue(current_frame)
            self.progress_bar.setFormat(f"{percentage:.1f}% - Frame {current_frame} de {total_frames}")
        else:
            self.progress_bar.setFormat(f"{percentage:.1f}%")
        
        # Atualizar texto da barra de status
        if percentage < 100:
            self.status_bar.showMessage(f"Processando vídeo: {percentage:.1f}%")
        else:
            self.status_bar.showMessage("Processamento concluído")
    
    def reset_interface(self):
        """Reset interface elements to initial state"""
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("0%")
        # ... outros resets ...