# Configuration settings for the application

from pathlib import Path

class Config:
    # Paths
    PROJECT_ROOT = Path(__file__).parent.parent.parent
    MODEL_PATH = str(PROJECT_ROOT / "data" / "models" / "best.pt")
    VIDEO_PATH = str(PROJECT_ROOT / "data" / "videos" / "12.mp4")
    OUTPUT_PATH = str(PROJECT_ROOT / "data" / "output")
    
    # Video settings
    VIDEO_WIDTH = 640
    VIDEO_HEIGHT = 368
    FPS = 30
    
    # Detection settings
    CONFIDENCE_THRESHOLD = 0.60