def resize_image(image, width, height):
    return cv2.resize(image, (width, height))

def convert_color(image, color_space):
    if color_space == 'RGB':
        return cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    elif color_space == 'BGR':
        return cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    else:
        raise ValueError("Unsupported color space")

def draw_rectangle(frame, coordinates, color, thickness=1):
    xmin, ymin, xmax, ymax = coordinates
    cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), color, thickness)

def put_text(frame, text, position, font=cv2.FONT_HERSHEY_SIMPLEX, font_scale=0.5, color=(255, 255, 255), thickness=1):
    cv2.putText(frame, text, position, font, font_scale, color, thickness)

def save_image(image, path):
    cv2.imwrite(path, image)