import math
import cv2

def calculate_distance(point1, point2):
    return math.sqrt((point2[0] - point1[0])**2 + (point2[1] - point1[1])**2)

def draw_measurement(frame, p1, p2, distance_mm, color=(255, 0, 255)):
    cv2.line(frame, p1, p2, color, 1)
    mid_point = ((p1[0] + p2[0])//2, (p1[1] + p2[1])//2)
    cv2.putText(frame, f'{distance_mm:.1f}mm', mid_point, 
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)