import torch
from PIL import Image
import numpy as np
import cv2  # Adicione esta linha para importar a biblioteca OpenCV

class Detector:
    def __init__(self, model_path):
        self.model_path = model_path
        self.model = None
        self.load_model()
        
    def load_model(self):
        try:
            self.model = torch.hub.load('ultralytics/yolov5', 'custom', path=self.model_path)
            self.model.conf = 0.60
        except Exception as e:
            print(f"Error loading model: {e}")
            self.model = None

    def detect_objects(self, image):
        image_rgb = cv2.cvtColor(np.array(image), cv2.COLOR_BGR2RGB)
        results = self.model(image_rgb)
        return results.pandas().xyxy[0]

    def get_predictions(self, predictions):
        detected_objects = []
        for _, detection in predictions.iterrows():
            detected_objects.append({
                'class': detection['name'],
                'confidence': detection['confidence'],
                'bbox': [detection['xmin'], detection['ymin'], detection['xmax'], detection['ymax']]
            })
        return detected_objects