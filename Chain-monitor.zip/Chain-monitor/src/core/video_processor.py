import os
import cv2
import torch
import numpy as np
import math
import json
from PIL import Image
from pathlib import Path
from PyQt5.QtCore import QThread, pyqtSignal, QMutex, QSize
from PyQt5.QtGui import QImage, QPixmap

class VideoProcessor(QThread):
    frame_processed = pyqtSignal(QPixmap)
    stats_updated = pyqtSignal(dict)
    warning_detected = pyqtSignal(str)
    progress_updated = pyqtSignal(float)  # Adicione esta linha para definir o sinal progress_updated
    
    def __init__(self, model_path="data/models/best.pt", video_path="data/videos/12.mp4"):
        super().__init__()
        self.model_path = model_path
        self.video_path = video_path
        self.running = False
        self.mutex = QMutex()
        
        # Measurements and detection variables
        self.detections_count_elo = 0
        self.detect_elo = True
        self.distance_mm = 0
        self.distance_real_mm = 0
        self.detections_count_rolete = 0
        self.detect_rolete = False
        self.detections_count_parafuso_1 = 0
        self.center_parafuso_1 = 0
        self.detect_parafuso_1 = False
        self.detections_count_parafuso_2 = 0
        self.center_parafuso_2 = 0
        self.detect_parafuso_2 = False
        self.center_arrastador = 0
        self.detections_count_arrastador = 0
        self.detect_arrastador = False
        self.tamanho_corrente = 0
        self.elo_troca = 0
        self.back_distance = 0
        self.major_distance = 0
        self.elo_change = []
        self.elos = []
        self.mensure_elos = []
        self.contagem_trigger = False
        self.escala_real_por_pixel = None
        self.gabarito_width_pixels = 37  # Default value
        self.gabarito_width_measurements = []
        self.wear_threshold = 128.5  # mm - threshold for wear detection
        self.elo_locations = []  # Adicione esta linha para armazenar a localização do elo
        
        # Save directory for detected frames and reports
        self.output_dir = Path("data/output")
        self.output_dir.mkdir(exist_ok=True, parents=True)
        
        # Load model
        self._load_model()
    
    def _load_model(self):
        try:
            # Resolve the model path relative to the project root
            project_root = Path(__file__).parent.parent.parent
            full_model_path = project_root / self.model_path
            
            if not full_model_path.exists():
                raise FileNotFoundError(f"Model file not found: {full_model_path}")
                
            # Use device 
            self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            
            # Load YOLOv5 model
            self.model = torch.hub.load('ultralytics/yolov5', 'custom', 
                                        path=str(full_model_path), 
                                        force_reload=False)
            self.model.conf = 0.60
            self.model.to(self.device).eval()
            
            print(f"Model loaded successfully from {full_model_path} using {self.device}")
        except Exception as e:
            print(f"Error loading model: {e}")
            raise
    
    def start(self):
        self.mutex.lock()
        self.running = True
        self.mutex.unlock()
        super().start()
    
    def stop(self):
        self.mutex.lock()
        self.running = False
        self.mutex.unlock()
        self.wait()
    
    def is_running(self):
        self.mutex.lock()
        result = self.running
        self.mutex.unlock()
        return result
    
    def set_video_path(self, path):
        self.mutex.lock()
        self.video_path = path
        self.mutex.unlock()
    
    def set_model_path(self, path):
        self.mutex.lock()
        self.model_path = path
        self._load_model()
        self.mutex.unlock()
    
    def reset_stats(self):
        self.mutex.lock()
        self.detections_count_elo = 0
        self.detections_count_rolete = 0
        self.detections_count_parafuso_1 = 0
        self.detections_count_parafuso_2 = 0
        self.detections_count_arrastador = 0
        self.tamanho_corrente = 0
        self.elo_troca = 0
        self.elo_change = []
        self.mensure_elos = []
        self.mutex.unlock()
    
    def save_report(self):
        """Save detection results to a JSON file"""
        resultados = {
            'detections_count_elo': self.detections_count_elo,
            'detections_count_rolete': self.detections_count_rolete,
            'detections_count_parafuso_1': self.detections_count_parafuso_1,
            'detections_count_parafuso_2': self.detections_count_parafuso_2,
            'detections_count_arrastador': self.detections_count_arrastador,
            'tamanho_corrente': self.tamanho_corrente,
            'elo_troca': self.elo_troca,
            'elo_change': self.elo_change,
            'medidas_elo': self.mensure_elos,
            'major_distance': self.major_distance,
            'localizacao_elo': self.elo_locations  # Adicione esta linha para incluir localizacao_elo
        }
        
        json_output_path = self.output_dir / "relatorio.json"
        with open(json_output_path, 'w') as f:
            json.dump(resultados, f)
        
        return json_output_path
    
    def run(self):
        # Resolve video path
        project_root = Path(__file__).parent.parent.parent
        full_video_path = project_root / self.video_path
        
        # Open video capture
        cap = cv2.VideoCapture(str(full_video_path))
        if not cap.isOpened():
            print(f"Error: Could not open video {full_video_path}")
            return
        
        # Set frame dimensions
        novo_largura = 640
        novo_altura = 368
        middle_line = novo_largura // 2
        
        while self.is_running() and cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            
            # Resize frame
            frame = cv2.resize(frame, (novo_largura, novo_altura))
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            # Convert to PIL image for YOLOv5
            image_pil = Image.fromarray(frame_rgb)
            
            # Run inference
            results = self.model(image_pil)
            predictions = results.pandas().xyxy[0]
            
            # Draw info panel
            frame_height, frame_width, _ = frame.shape
            info_panel_height = 80
            info_panel_y = frame_height - info_panel_height
            
            # Draw semi-transparent panel
            overlay = frame.copy()
            cv2.rectangle(overlay, (0, info_panel_y), (frame_width, frame_height), (240, 240, 240), -1)
            #cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
            
            # Draw measurement line
            cv2.line(frame, (middle_line, 0), (middle_line, info_panel_y), (192, 192, 192), 2)
            #cv2.line(frame, (0, info_panel_y), (frame_width, info_panel_y), (192, 192, 192), 2)
            
            # Process detections
            self._process_detections(predictions, frame, middle_line, info_panel_y)
            
            # Display stats
            self._draw_stats(frame, frame_height, info_panel_height)
            
            # Convert to QPixmap and emit signal
            h, w, c = frame.shape
            bytes_per_line = c * w
            qt_image = QImage(frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
            pixmap = QPixmap.fromImage(qt_image)
            self.frame_processed.emit(pixmap)
            
            # Update stats
            stats = {
                'elo_count': self.detections_count_elo,
                'rolete_count': self.detections_count_rolete,
                'parafuso1_count': self.detections_count_parafuso_1,
                'parafuso2_count': self.detections_count_parafuso_2,
                'arrastador_count': self.detections_count_arrastador,
                'corrente_length': self.tamanho_corrente,
                'worn_links': self.elo_troca,
                'current_measurement': self.distance_real_mm,
                'medidas_elo': self.mensure_elos,  # Adicione esta linha para incluir medidas_elo
                'localizacao_elo': self.elo_locations  # Adicione esta linha para incluir localizacao_elo
            }
            self.stats_updated.emit(stats)
            
            # Update progress
            progress = (cap.get(cv2.CAP_PROP_POS_FRAMES) / cap.get(cv2.CAP_PROP_FRAME_COUNT)) * 100
            self.progress_updated.emit(progress)
            
            # Check for thread termination
            if not self.is_running():
                break
        
        # Release resources
        cap.release()
        self.save_report()
    
    def _process_detections(self, predictions, frame, middle_line, info_panel_y):
        """Process all detected objects in the current frame"""
        for _, detection in predictions.iterrows():
            class_name = detection['name']
            xmin, ymin, xmax, ymax = int(detection['xmin']), int(detection['ymin']), int(detection['xmax']), int(detection['ymax'])
            
            # Process each object type
            if class_name == 'Parafuso_1':
                self._process_parafuso_1(detection, frame, middle_line, xmin, ymin, xmax, ymax)
            elif class_name == 'Parafuso_2':
                self._process_parafuso_2(detection, frame, middle_line, xmin, ymin, xmax, ymax)
            elif class_name == 'Rolete':
                self._process_rolete(detection, frame, middle_line, xmin, ymin, xmax, ymax)
            elif class_name == 'Arrastador':
                self._process_arrastador(detection, frame, middle_line, xmin, ymin, xmax, ymax)
            elif class_name == 'Elo':
                self._process_elo(detection, predictions, frame, middle_line, info_panel_y, xmin, ymin, xmax, ymax)
    
    def _process_parafuso_1(self, detection, frame, middle_line, xmin, ymin, xmax, ymax):
        """Process Parafuso_1 detections and handle calibration"""
        # Calculate and store measurements for calibration
        self.gabarito_width_pixels = 37  # Default test value
        self.gabarito_width_measurements.append(self.gabarito_width_pixels)
        
        # If we have enough measurements, calculate the average for more stable results
        if len(self.gabarito_width_measurements) == 10:
            average_width = sum(self.gabarito_width_measurements) / len(self.gabarito_width_measurements)
            self.gabarito_width_measurements = []
            self.gabarito_width_pixels = average_width
        
        # Calculate real scale (40mm is the real width of the reference object)
        self.escala_real_por_pixel = 40 / self.gabarito_width_pixels
        
        # Draw bounding box
        cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (0, 255, 255), 1)
        cv2.putText(frame, 'Parafuso_1', (xmin, ymin - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (0, 255, 255), 1)
        
        # Calculate center point
        self.center_parafuso_1 = (xmin + xmax) // 2
        
        # Count when crossing the measurement line
        if xmin <= middle_line <= xmax:
            if middle_line > self.center_parafuso_1 and self.detect_parafuso_1:
                self.detect_parafuso_1 = False
                self.detections_count_parafuso_1 += 1
            
            if middle_line < self.center_parafuso_1 and not self.detect_parafuso_1:
                self.detect_parafuso_1 = True
    
    def _process_parafuso_2(self, detection, frame, middle_line, xmin, ymin, xmax, ymax):
        """Process Parafuso_2 detections"""
        # Draw bounding box
        cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (255, 255, 255), 1)
        cv2.putText(frame, 'Parafuso_2', (xmin, ymin - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)
        
        # Calculate center point
        self.center_parafuso_2 = (xmin + xmax) // 2
        
        # Count when crossing the measurement line
        if xmin <= middle_line <= xmax:
            if middle_line > self.center_parafuso_2 and self.detect_parafuso_2:
                self.detect_parafuso_2 = False
                self.detections_count_parafuso_2 += 1
            
            if middle_line < self.center_parafuso_2 and not self.detect_parafuso_2:
                self.detect_parafuso_2 = True
    
    def _process_rolete(self, detection, frame, middle_line, xmin, ymin, xmax, ymax):
        """Process Rolete detections"""
        # Draw bounding box
        cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (255, 255, 0), 1)
        cv2.putText(frame, 'Rolete', (xmin, ymin - 2), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 0), 1)
        
        # Calculate center point
        center_rolete = (xmin + xmax) // 2
        
        # Count when crossing the measurement line
        if xmin <= middle_line <= xmax:
            if middle_line > center_rolete and self.detect_rolete:
                self.detect_rolete = False
                self.detections_count_rolete += 1
            
            if middle_line < center_rolete and not self.detect_rolete:
                self.detect_rolete = True
    
    def _process_arrastador(self, detection, frame, middle_line, xmin, ymin, xmax, ymax):
        """Process Arrastador detections"""
        # Draw bounding box
        cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (0, 0, 255), 1)
        cv2.putText(frame, 'Arrastador', (xmin, ymax + 8), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (0, 0, 255), 1)
        
        # Calculate center point
        self.center_arrastador = (xmin + xmax) // 2
        
        # Count when crossing the measurement line
        if xmin <= middle_line <= xmax:
            if middle_line > self.center_arrastador and self.detect_arrastador:
                self.detect_arrastador = False
                self.detections_count_arrastador += 1
            
            if middle_line < self.center_arrastador and not self.detect_arrastador:
                self.detect_arrastador = True
    
    def _process_elo(self, detection, predictions, frame, middle_line, info_panel_y, xmin, ymin, xmax, ymax):
        """Process Elo (link) detections and measure wear"""
        # Draw bounding box
        cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (0, 255, 0), 1)
        cv2.putText(frame, 'Elo', (xmin, ymin - 2), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (0, 255, 0), 1)
        
        # Measure link dimensions using border points
        if xmin <= middle_line <= xmax and not self.contagem_trigger:
            self.contagem_trigger = True
            center_bordas = []
            
            # Find border points within this Elo
            for _, detection_borda in predictions.iterrows():
                class_name_borda = detection_borda['name']
                if (class_name_borda.startswith('Borda_') and 
                    xmin <= detection_borda['xmin'] <= xmax and 
                    ymin <= detection_borda['ymin'] <= ymax):
                    
                    center_x = (detection_borda['xmin'] + detection_borda['xmax']) // 2
                    center_y = (detection_borda['ymin'] + detection_borda['ymax']) // 2
                    center_borda = (center_x, center_y)
                    center_bordas.append(center_borda)
                    cv2.circle(frame, (int(center_x), int(center_y)), 3, (0, 0, 255), -1)
            
            # Calculate distance between border points if we found at least 2
            if len(center_bordas) >= 2 and self.escala_real_por_pixel is not None:
                distance_pixels = math.sqrt(
                    (center_bordas[1][0] - center_bordas[0][0])**2 + 
                    (center_bordas[1][1] - center_bordas[0][1])**2
                )
                self.distance_real_mm = distance_pixels * self.escala_real_por_pixel
                
                # Draw measurement line between borders
                cv2.line(
                    frame, 
                    (int(center_bordas[0][0]), int(center_bordas[0][1])),
                    (int(center_bordas[1][0]), int(center_bordas[1][1])), 
                    (255, 0, 255), 1
                )
        
        # Reset trigger when elo is no longer crossing the line
        elif middle_line < xmin or middle_line > xmax:
            self.contagem_trigger = False
        
        # Count Elo when crossing measurement line
        if xmin <= middle_line <= xmax:
            center_elo = (xmax - 15)  # Offset used in original code
            
            # When the elo center crosses the line from left to right
            if middle_line > center_elo and self.detect_elo:
                self.detect_elo = False
                self.detections_count_elo += 1
                
                # Calculate chain length
                self.tamanho_corrente = self.tamanho_corrente + self.distance_real_mm * 2 / 1000
                
                # Highlight measurement line
                cv2.putText(frame, 'Measured', (xmin + 50, ymin - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (0, 0, 255), 1)
                cv2.line(frame, (middle_line, 0), (middle_line, info_panel_y), (255, 0, 255), 2)
                
                # Track largest distance
                if self.distance_real_mm > self.back_distance:
                    self.back_distance = self.distance_real_mm
                    self.major_distance = self.distance_real_mm
                
                # Check for wear based on measurement threshold
                if self.distance_real_mm >= self.wear_threshold:
                    self.elo_troca += 1
                    
                    # Show warning
                    warning_text = 'Elo Desgastado! Programar Troca'
                    cv2.putText(
                        frame, warning_text, 
                        (130, info_panel_y - 10), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2
                    )
                    
                    # Add to list of worn links
                    self.elo_change.append(self.detections_count_elo)
                    
                    # Emit warning signal
                    self.warning_detected.emit(
                        f"Desgaste detectado no elo #{self.detections_count_elo}! Medida: {self.distance_real_mm:.2f}mm"
                    )
                
                # Save measurements
                self.mensure_elos.append(self.distance_real_mm)
                
                # Save location
                self.elo_locations.append(f"a {self.tamanho_corrente:.2f}m do início")
                
                # Save frame if needed
                self._save_detection_image(frame)
            
            # When the elo center crosses the line from right to left
            if middle_line < center_elo and not self.detect_elo:
                self.detect_elo = True
    
    def _draw_stats(self, frame, frame_height, info_panel_height):
        """Draw statistics on the frame's info panel"""
        #y_base = frame_height - info_panel_height + 15
        
        # Left column stats
        #cv2.putText(frame, f'Medida: {self.distance_real_mm:.2f} mm', 
                  # (10, y_base + 40), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2)
        
        #cv2.putText(frame, f'Elos: {self.detections_count_elo}', 
                   #(10, y_base), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
        
        #cv2.putText(frame, f'Roletes: {self.detections_count_rolete}', 
                   #(10, y_base + 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
        
        # Right column stats
        #cv2.putText(frame, f'Comprimento: {self.tamanho_corrente:.2f} m', 
                   #(330, y_base), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
        
        #cv2.putText(frame, f'Elos para troca: {self.elo_troca}', 
                   #(330, y_base + 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
    
    def _save_detection_image(self, frame):
        """Save detected elo frame if needed"""
        output_path = self.output_dir / f"detected_elo_{self.detections_count_elo}.jpg"
        cv2.imwrite(str(output_path), frame)
    
    def set_wear_limit(self, limit):
        """Set wear threshold limit"""
        self.wear_threshold = limit
        print(f"Wear limit updated to: {limit:.1f}mm")