import sys
import os
from pathlib import Path

# Add src directory to Python path
src_dir = Path(__file__).parent
project_root = src_dir.parent
sys.path.append(str(project_root))

from PyQt5.QtWidgets import QApplication, QFileDialog, QMessageBox
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from src.gui.main_window import MainWindow
from src.core.video_processor import VideoProcessor
from src.gui.styles import DARK_STYLE

def main():
    # Verificar se PyQtChart está disponível
    try:
        from PyQt5.QtChart import QChart
        has_chart = True
    except ImportError:
        has_chart = False
        print("\n" + "="*80)
        print("AVISO: PyQtChart não detectado!")
        print("A visualização de gráficos requer o pacote PyQtChart.")
        print("Para instalar, execute: pip install PyQtChart")
        print("="*80 + "\n")
    
    app = QApplication(sys.argv)
    
    # Apply dark theme to the entire application
    app.setStyle("Fusion")  # Fusion style works well with custom stylesheets
    app.setStyleSheet(DARK_STYLE)
    
    # Set application icon
    icon_path = project_root / "resources" / "images" / "savision.png"
    if os.path.exists(icon_path):
        app.setWindowIcon(QIcon(str(icon_path)))
    
    window = MainWindow()
    
    # Set window title
    window.setWindowTitle("Savision Chain Monitor")
    
    try:
        # Create video processor with relative paths
        video_processor = VideoProcessor(
            model_path="data/models/best.pt",  # Verifique se o caminho do modelo está correto
            video_path="data/videos/12.mp4"    # Verifique se o caminho do vídeo está correto
        )
        
        # Connect signals
        video_processor.frame_processed.connect(window.update_frame)
        video_processor.stats_updated.connect(window.update_stats)
        video_processor.warning_detected.connect(window.add_warning_message)
        video_processor.progress_updated.connect(window.update_progress)
        
        # Connect buttons
        window.start_button.clicked.connect(video_processor.start)
        window.stop_button.clicked.connect(video_processor.stop)
        window.reset_button.clicked.connect(video_processor.reset_stats)
        window.clean_view_toggle.clicked.connect(lambda checked: video_processor.set_clean_view(checked))
        window.wear_limit_changed.connect(video_processor.set_wear_limit)
        
        # Adicionar conexão para o botão de seleção de vídeo
        def select_video():
            file_path, _ = QFileDialog.getOpenFileName(
                window, "Selecionar Vídeo", "data/videos", "Arquivos de Vídeo (*.mp4 *.avi *.mkv)")
            if file_path:
                video_processor.set_video_path(file_path)
                window.status_bar.showMessage(f"Vídeo selecionado: {file_path}")
        
        window.source_button.clicked.connect(select_video)
        
        # Adicionar conexão para salvar relatório
        def save_report():
            try:
                if video_processor.stats['elo_count'] > 0:
                    report_path = video_processor.save_report()
                    QMessageBox.information(window, "Relatório Salvo", 
                                           f"Relatório salvo com sucesso em:\n{report_path}")
                else:
                    QMessageBox.warning(window, "Sem Dados", 
                                       "Não há dados suficientes para gerar um relatório. Execute o processamento primeiro.")
            except Exception as e:
                QMessageBox.critical(window, "Erro", f"Erro ao salvar relatório: {str(e)}")
        
        if hasattr(window, 'save_button'):
            window.save_button.clicked.connect(save_report)
        
        window.show()
        sys.exit(app.exec_())
        
    except Exception as e:
        print(f"Erro fatal na aplicação: {str(e)}")
        QMessageBox.critical(None, "Erro Fatal", 
                            f"Ocorreu um erro crítico na aplicação:\n{str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()