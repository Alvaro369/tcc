import unittest
from src.core.detector import Detector

class TestDetector(unittest.TestCase):

    def setUp(self):
        self.detector = Detector()
        self.detector.load_model('resources/models/best.pt')

    def test_detect_objects(self):
        # Assuming we have a test image or frame
        test_frame = ...  # Load or create a test frame
        predictions = self.detector.detect_objects(test_frame)
        self.assertIsInstance(predictions, list)
        self.assertGreater(len(predictions), 0)

    def test_get_predictions(self):
        test_frame = ...  # Load or create a test frame
        self.detector.detect_objects(test_frame)
        predictions = self.detector.get_predictions()
        self.assertIsInstance(predictions, list)

if __name__ == '__main__':
    unittest.main()