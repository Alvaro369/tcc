import unittest
from src.core.video_processor import VideoProcessor

class TestVideoProcessor(unittest.TestCase):

    def setUp(self):
        self.video_processor = VideoProcessor("test_video.mp4", "output_video.avi")

    def test_start_capture(self):
        self.video_processor.start_capture()
        self.assertTrue(self.video_processor.cap.isOpened())

    def test_process_frame(self):
        self.video_processor.start_capture()
        ret, frame = self.video_processor.cap.read()
        self.assertTrue(ret)
        processed_frame = self.video_processor.process_frame(frame)
        self.assertIsNotNone(processed_frame)

    def test_save_output(self):
        self.video_processor.start_capture()
        self.video_processor.save_output()
        # Check if the output file is created (this is a simple check)
        self.assertTrue(os.path.exists("output_video.avi"))

    def tearDown(self):
        self.video_processor.cap.release()

if __name__ == '__main__':
    unittest.main()